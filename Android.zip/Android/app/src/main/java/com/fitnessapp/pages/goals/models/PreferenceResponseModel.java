package com.fitnessapp.pages.goals.models;

import com.fitnessapp.models.ApiResponseModel;

public class PreferenceResponseModel extends ApiResponseModel {
    public PrefernceModel data;
}

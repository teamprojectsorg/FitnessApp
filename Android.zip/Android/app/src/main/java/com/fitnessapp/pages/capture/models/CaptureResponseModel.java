package com.fitnessapp.pages.capture.models;

import com.fitnessapp.models.ApiResponseModel;

public class CaptureResponseModel extends ApiResponseModel {
    public CaptureModel[] data;
}

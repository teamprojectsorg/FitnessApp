package com.fitnessapp.network.results;

import com.fitnessapp.network.NetworkResult;

public class LoadingResult<T> extends NetworkResult<T>
{
    public LoadingResult()
    {
        super();
    }
}

package com.fitnessapp.pages.profile.models;

import com.fitnessapp.models.ApiResponseModel;

public class ProfileResponseModel extends ApiResponseModel {
    public ProfileModel data;
}

package com.fitnessapp.pages.capture.models;

public class CaptureModel {
    public String drinkIntake;
    public String drinkIntension;
    public String alcoholPercentage;
    public String date;
    public String drinkName;
}

package com.fitnessapp.pages.goals.models;

public class PrefernceModel {
    public String currentIntake;
    public String previousIntake;
}

package com.fitnessapp.models;

public class ApiResponseModel {
    public boolean status;
    public String message;
}

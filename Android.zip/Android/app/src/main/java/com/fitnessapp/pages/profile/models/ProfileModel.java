package com.fitnessapp.pages.profile.models;

public class ProfileModel {
    public String username;
    public String name;
    public String age;
}

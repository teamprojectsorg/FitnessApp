package com.fitnessapp.utils;

public class Constants {
    public static final int BAR_COUNT = 7;
        }

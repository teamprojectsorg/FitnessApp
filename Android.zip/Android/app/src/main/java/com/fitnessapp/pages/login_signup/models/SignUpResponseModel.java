package com.fitnessapp.pages.login_signup.models;

import com.fitnessapp.models.ApiResponse;

public class SignUpResponseModel extends ApiResponse {
    public LoginSignUpModel data;
}

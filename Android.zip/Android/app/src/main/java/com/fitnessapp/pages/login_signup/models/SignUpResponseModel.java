package com.fitnessapp.pages.login_signup.models;

import com.fitnessapp.models.ApiResponseModel;

public class SignUpResponseModel extends ApiResponseModel {
    public LoginSignUpModel data;
}

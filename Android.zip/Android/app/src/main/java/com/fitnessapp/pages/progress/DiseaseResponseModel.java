package com.fitnessapp.pages.progress;

import com.fitnessapp.models.ApiResponseModel;

public class DiseaseResponseModel extends ApiResponseModel {
    public DiseaseModel data;

    class DiseaseModel
    {
        public String diseaseRisk;
    }
}

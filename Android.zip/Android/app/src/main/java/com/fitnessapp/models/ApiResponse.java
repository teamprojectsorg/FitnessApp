package com.fitnessapp.models;

public abstract class ApiResponse {
    public boolean status;
    public String message;
}
